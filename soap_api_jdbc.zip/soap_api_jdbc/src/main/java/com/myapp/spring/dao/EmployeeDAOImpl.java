package com.myapp.spring.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.myapp.spring.model.Employee;
import com.myapp.spring.model.EmployeeMapper;


@Component
public class EmployeeDAOImpl implements EmployeeDAO{
	
	
	JdbcTemplate jdbcTemplate;
	

	//out table name is employee it is in 'firstdb'  database
	private final String SQL_FIND = "select * from employee where id = ?";
	private final String SQL_DELETE = "delete from employee where id = ?";
	private final String SQL_UPDATE = "update employee set firstname = ?, lastname = ?, dob  = ?,permanentaddress = ?,currentaddress = ?,department = ?,phonenumber = ?,trainingattended = ?  where id = ?";
	private final String SQL_GET_ALL = "select * from employee";
	private final String SQL_INSERT = "insert into employee(id, firstname, lastname, dob,permanentaddress,currentaddress,department,phonenumber,trainingattended) values(?,?,?,?,?,?,?,?,?)";
	
	
	@Autowired
	public EmployeeDAOImpl(DataSource dataSource) {
			jdbcTemplate = new JdbcTemplate(dataSource);
		}
	
	
	@Override
	public Employee save(Employee employee) {
		// TODO Auto-generated method stub
		//return 0;
		
		jdbcTemplate.update(SQL_INSERT,employee.getId(),employee.getFirstname(),employee.getLastname(),employee.getDob(),employee.getPermanentaddress(),employee.getCurrentaddress(),employee.getDepartment(),employee.getPhonenumber(),employee.getTrainingattended() );
		
		return employee;
	}

	@Override
	public Employee get(long id) {
	
	//return sessionFactory.getCurrentSession().get(Employee.class, id);
		return jdbcTemplate.queryForObject(SQL_FIND, new Object[] { id }, new EmployeeMapper());
		
	}

	@Override
	public List<Employee> list() {
		
		return jdbcTemplate.query(SQL_GET_ALL, new EmployeeMapper());
		
		
	}

	@Override
	public boolean update(Employee employee) {
		
		 return jdbcTemplate.update(SQL_UPDATE, employee.getFirstname(),employee.getLastname(),employee.getDob(),employee.getPermanentaddress(),employee.getCurrentaddress(),employee.getDepartment(),employee.getPhonenumber(),employee.getTrainingattended(),
				 employee.getId()) > 0;
		
		
	}

	@Override
	public boolean delete(long id) {
		// TODO Auto-generated method stub
		System.out.println("delete id"+id );
		return  jdbcTemplate.update(SQL_DELETE, id) > 0;
		
	}

}
