package com.myapp.spring.service;

import java.util.List;

import com.myapp.spring.model.Employee;



public interface EmployeeService {
	
			//long save(Employee employee);
			
			Employee save(Employee employee);
			
			Employee get(long id);
			
			List<Employee> list();
			
			boolean update(Employee employee);
			
			boolean delete(long id);
}
