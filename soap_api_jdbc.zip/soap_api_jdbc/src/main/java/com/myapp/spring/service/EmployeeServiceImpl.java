package com.myapp.spring.service;

import java.util.List;


import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.myapp.spring.dao.EmployeeDAO;
import com.myapp.spring.model.Employee;




@Service //since it is a service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeDAO employeeDAO;
	
	
	
	@Override
	@Transactional//letus replace with javax if this didn't work out 
	public Employee save(Employee employee) {
		// TODO Auto-generated method stub
		//return 0;
		
		return employeeDAO.save(employee);
	}

	@Override
	@Transactional
	public Employee get(long id) {
		// TODO Auto-generated method stub
		return employeeDAO.get(id);
	}

	@Override
	@Transactional
	public List<Employee> list() {
		// TODO Auto-generated method stub
		return employeeDAO.list();
	}

	@Transactional
	@Override
	public boolean update( Employee employee) {
		// TODO Auto-generated method stub
		boolean val = employeeDAO.update(employee);
		return val ;
		
	}

	@Transactional
	@Override
	public boolean delete(long id) {
		// TODO Auto-generated method stub
		return employeeDAO.delete(id) ;
		
	}

	
	
}
