package com.myapp.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapApiJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapApiJdbcApplication.class, args);
	}

}
