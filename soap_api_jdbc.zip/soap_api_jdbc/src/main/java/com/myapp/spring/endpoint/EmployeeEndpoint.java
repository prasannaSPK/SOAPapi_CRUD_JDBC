package com.myapp.spring.endpoint;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.javaspringclub.gs_ws.AddEmployeeRequest;
import com.javaspringclub.gs_ws.AddEmployeeResponse;
import com.javaspringclub.gs_ws.DeleteEmployeeRequest;
import com.javaspringclub.gs_ws.DeleteEmployeeResponse;
import com.javaspringclub.gs_ws.EmployeeType;
import com.javaspringclub.gs_ws.GetAllEmployeesRequest;
import com.javaspringclub.gs_ws.GetAllEmployeesResponse;
import com.javaspringclub.gs_ws.GetEmployeeByIdRequest;
import com.javaspringclub.gs_ws.GetEmployeeByIdResponse;
import com.javaspringclub.gs_ws.ServiceStatus;
import com.javaspringclub.gs_ws.UpdateEmployeeRequest;
import com.javaspringclub.gs_ws.UpdateEmployeeResponse;
import com.myapp.spring.model.Employee;
import com.myapp.spring.service.EmployeeService;

@Endpoint
public class EmployeeEndpoint {

	public static final String NAMESPACE_URI = "http://www.example.org/employee";
	
	private EmployeeService service;
	
	public EmployeeEndpoint() {
		
	}
	
	@Autowired
	public EmployeeEndpoint(EmployeeService service) {
				
		this.service = service;
	}
	
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getEmployeeByIdRequest")
	@ResponsePayload
	public GetEmployeeByIdResponse getEmployeeById(@RequestPayload GetEmployeeByIdRequest request) {
		GetEmployeeByIdResponse response = new GetEmployeeByIdResponse();
		Employee employeeModel = service.get(request.getEmployeeId());
		EmployeeType employeeType = new EmployeeType();
		BeanUtils.copyProperties(employeeModel, employeeType);
		response.setEmployeeType(employeeType);
		return response;

	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getAllEmployeesRequest")
	@ResponsePayload
	public GetAllEmployeesResponse getAllEmployees(@RequestPayload GetAllEmployeesRequest request) {
		GetAllEmployeesResponse response = new GetAllEmployeesResponse();
		List<EmployeeType> employeeTypeList = new ArrayList<EmployeeType>();
		List<Employee> employeeModelList = service.list();
		for (Employee employeeModel : employeeModelList) {
			EmployeeType employeeType = new EmployeeType();
			BeanUtils.copyProperties(employeeModel, employeeType);
			employeeTypeList.add(employeeType);
		}
		response.getEmployeeType().addAll(employeeTypeList);

		return response;

	}
	


	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "addEmployeeRequest")
	@ResponsePayload
	public AddEmployeeResponse addEmployee(@RequestPayload AddEmployeeRequest request) {
		AddEmployeeResponse response = new AddEmployeeResponse();
		EmployeeType employeeType = new EmployeeType();
		ServiceStatus serviceStatus = new ServiceStatus();

		
		
		Employee newEmployeeModel = new Employee(request.getFirstname(),request.getLastname(),request.getDob(),request.getPermanentaddress(),request.getCurrentaddress(),request.getDepartment(),request.getPhonenumber(),request.getTrainingattended());
		
		Employee savedEmployeeModel = service.save(newEmployeeModel);
		if (savedEmployeeModel == null) {
			serviceStatus.setStatusCode("CONFLICT");
			serviceStatus.setMessage("Exception while adding Entity");
		} else {

			BeanUtils.copyProperties(savedEmployeeModel, newEmployeeModel);
			serviceStatus.setStatusCode("SUCCESS");
			serviceStatus.setMessage("Content Added Successfully");
		}
		
		response.setEmployeeType(employeeType);
		response.setServiceStatus(serviceStatus);
		return response;

	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "updateEmployeeRequest")
	@ResponsePayload
	public UpdateEmployeeResponse updateEmployee(@RequestPayload UpdateEmployeeRequest request) {
		UpdateEmployeeResponse response = new UpdateEmployeeResponse();
		ServiceStatus serviceStatus = new ServiceStatus();
	
		
		
		Employee empModel = service.get(request.getEmployeeId());
		
		
		empModel.setFirstname(request.getFirstname());
		empModel.setLastname(request.getLastname());
		empModel.setDob(request.getDob());
		empModel.setCurrentaddress(request.getCurrentaddress());
		empModel.setPermanentaddress(request.getPermanentaddress());
		empModel.setPhonenumber(request.getPhonenumber());
		empModel.setDepartment(request.getDepartment());
		empModel.setTrainingattended(request.getTrainingattended());
		
		
			
			
			
			boolean flag = service.update(empModel);
			
			if(flag == false) {
				serviceStatus.setStatusCode("CONFLICT");
				serviceStatus.setMessage("Exception while updating Entity=" + request.getEmployeeId());;
			}else {
				serviceStatus.setStatusCode("SUCCESS");
				serviceStatus.setMessage("Content updated Successfully");
			}
			
			
		
		
		response.setServiceStatus(serviceStatus);
		return response;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "deleteEmployeeRequest")
	@ResponsePayload
	public DeleteEmployeeResponse deleteEmployee(@RequestPayload DeleteEmployeeRequest request) {
		DeleteEmployeeResponse response = new DeleteEmployeeResponse();
		ServiceStatus serviceStatus = new ServiceStatus();

		boolean flag = service.delete(request.getEmployeeId());

		if (flag == false) {
			serviceStatus.setStatusCode("FAIL");
			serviceStatus.setMessage("Exception while deleting Entity id=" + request.getEmployeeId());
		} else {
			serviceStatus.setStatusCode("SUCCESS");
			serviceStatus.setMessage("Content Deleted Successfully");
		}

		response.setServiceStatus(serviceStatus);
		return response;
	}
	
	
}
